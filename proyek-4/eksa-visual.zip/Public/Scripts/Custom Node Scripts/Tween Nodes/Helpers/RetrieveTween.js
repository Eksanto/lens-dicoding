// RettieveTween.js
// Version: 1.0.0
// Event: Lens Initialized
// Description: Easing function
//
// @input string key
// @output tweenObj tween

var key = "_tweenObj_"+script.key;
script.tween = script.api[key];