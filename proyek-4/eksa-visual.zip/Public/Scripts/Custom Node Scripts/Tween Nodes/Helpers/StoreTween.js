// StoreTween.js
// Version: 1.0.0
// Event: Lens Initialized
// Description: Easing function
//
// @input tweenObj tween
// @input string key

var key = "_tweenObj_"+script.key;
script.api[key] = script.tween;