// TweenStart.js
// Version: 1.0.0
// Event: Lens Initialized
// Description: Tween modifier
//
// @input tweenObj tweenIn
// @output tweenObj tweenOut

script.tweenOut = script.tweenIn.start();